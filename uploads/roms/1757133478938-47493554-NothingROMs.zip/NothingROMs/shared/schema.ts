import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const roms = pgTable("roms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  codename: text("codename").notNull(),
  maintainer: text("maintainer").notNull(),
  version: text("version").notNull(),
  androidVersion: text("android_version").notNull(),
  romType: text("rom_type").notNull(),
  buildStatus: text("build_status").notNull().default("stable"),
  downloadUrl: text("download_url").notNull(),
  checksum: text("checksum"),
  changelog: text("changelog"),
  isApproved: boolean("is_approved").notNull().default(false),
  downloadCount: integer("download_count").notNull().default(0),
  developerId: varchar("developer_id").references(() => developers.id),
  fileSize: text("file_size"),
  fileName: text("file_name"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertRomSchema = createInsertSchema(roms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  downloadCount: true,
  isApproved: true,
});

export type Rom = typeof roms.$inferSelect;
export type InsertRom = z.infer<typeof insertRomSchema>;

export const developers = pgTable("developers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  bio: text("bio"),
  telegramHandle: text("telegram_handle"),
  githubHandle: text("github_handle"),
  isVerified: boolean("is_verified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertDeveloperSchema = createInsertSchema(developers).pick({
  username: true,
  email: true,
  password: true,
  displayName: true,
  bio: true,
  telegramHandle: true,
  githubHandle: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertDeveloper = z.infer<typeof insertDeveloperSchema>;
export type Developer = typeof developers.$inferSelect;
export type LoginCredentials = z.infer<typeof loginSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
