import type { Express } from "express";
import bcrypt from "bcryptjs";
import { storage } from "../storage";
import { insertDeveloperSchema, loginSchema } from "@shared/schema";
import { z } from "zod";
import { generateToken } from "../middleware/auth";

export function registerAuthRoutes(app: Express) {
  // Developer registration
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertDeveloperSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingDeveloper = await storage.getDeveloperByUsernameOrEmail(
        validatedData.username,
        validatedData.email
      );
      
      if (existingDeveloper) {
        return res.status(400).json({ 
          message: "Username or email already exists" 
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 12);
      
      const developer = await storage.createDeveloper({
        ...validatedData,
        password: hashedPassword,
      });

      // Generate token
      const token = generateToken({
        id: developer.id,
        username: developer.username,
        email: developer.email,
      });

      res.status(201).json({
        message: "Developer registered successfully",
        token,
        developer: {
          id: developer.id,
          username: developer.username,
          email: developer.email,
          displayName: developer.displayName,
          isVerified: developer.isVerified,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid registration data", 
          errors: error.errors 
        });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register developer" });
    }
  });

  // Developer login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const developer = await storage.getDeveloperByUsername(username);
      
      if (!developer) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, developer.password);
      
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Generate token
      const token = generateToken({
        id: developer.id,
        username: developer.username,
        email: developer.email,
      });

      res.json({
        message: "Login successful",
        token,
        developer: {
          id: developer.id,
          username: developer.username,
          email: developer.email,
          displayName: developer.displayName,
          isVerified: developer.isVerified,
        },
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid login data", 
          errors: error.errors 
        });
      }
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to login" });
    }
  });

  // Get developer profile
  app.get("/api/auth/profile", async (req, res) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({ message: 'Access token required' });
    }

    try {
      const jwt = require('jsonwebtoken');
      const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      
      const developer = await storage.getDeveloperById(decoded.id);
      
      if (!developer) {
        return res.status(404).json({ message: "Developer not found" });
      }

      res.json({
        id: developer.id,
        username: developer.username,
        email: developer.email,
        displayName: developer.displayName,
        bio: developer.bio,
        telegramHandle: developer.telegramHandle,
        githubHandle: developer.githubHandle,
        isVerified: developer.isVerified,
        createdAt: developer.createdAt,
      });
    } catch (error) {
      res.status(403).json({ message: 'Invalid or expired token' });
    }
  });
}
